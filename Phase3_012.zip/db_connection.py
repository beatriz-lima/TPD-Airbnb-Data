import pandas as pd
import pandas.io.sql as sqlio
import psycopg2
import psycopg2.extras
import math

class dbconnection:

    #use postgres localhost
    use_local = False
    
    #settings
    server_host = "appserver-01.alunos.di.fc.ul.pt" if use_local == False else "localhost"
    port = 5432
    sslmode = "allow" if use_local == False else "disable"
    dbname = "tpd012" if use_local == False else "postgres"
    dbusername = "tpd012" if use_local == False else "postgres"
    dbpassword = "Airbnbosses69420" if use_local == False else "####"
    gssencmode = "prefer" if use_local == False else "disable"

    # define functions

    def run_sql_command(sql, conn):
        """Executes a single SQL statement from a string variable and the database credentials"""
        try:
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()
            success = True
        except psycopg2.DatabaseError as error:
            success = False
            print(error)
        finally:
            if conn is not None:
                conn.close()
        return success

    def query_table(conn, table_name):
        """Returns DataFrame with queried database table"""
        sql = "select * from {};".format(table_name)
        #return dataframe
        return sqlio.read_sql_query(sql, conn)

    def insert_data(df, table_name, conn):

        """Inserts selected data into dimension table in database"""
        df_columns = df.columns
        columns = ",".join(df_columns)
        values = "VALUES({})".format(",".join(["%s" for _ in df_columns])) 
        insert_stmt = "INSERT INTO {} ({}) {}".format(table_name,columns,values)
        success = True

        values = [[int(val) for val in value] for value in df.values]

        try:
            cursor = conn.cursor()
            psycopg2.extras.execute_batch(cursor, insert_stmt, values)
            conn.commit()
            success = True
        except psycopg2.DatabaseError as error:
            success = False
            print('Error on table {}'.format(table_name))
            print(error)
        finally:
            if conn is not None:
                conn.close()
        return success

    def query_kpis(conn, method='score'):

        if method == 'cs':
            kpi = method
            kpi_name = 'Customer_Satisfaction'
        elif method == 'profit':
            kpi = method
            kpi_name = 'Monthly_Profit_Per_Property'
        elif method == 'score':
            kpi = method
            kpi_name = 'Companies_Performance'
        else:
            kpi = method
            kpi_name = 'Generic'

        sql = """
        select round(avg({}) * 100, 2) as {} from metrics;
        """.format(kpi, kpi_name)

        try:
            cur = conn.cursor()
            cur.execute(sql)
            result = cur.fetchall()[0][0]
        except psycopg2.DatabaseError as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()
        return result